package com.example.exopickaxes;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.SimpleTier;

/**
 * Характеристики материалов.
 * Для сравнения (ваниль):
 *   алмаз:      прочность 1561, скорость 8.0, урон +3.0, зачарование 10
 *   незерит:    прочность 2031, скорость 9.0, урон +4.0, зачарование 15
 */
public final class ModTiers {
    private ModTiers() {}

    // Фторкирка: лучше алмазной, но слабее экзокирки
    public static final Tier FLUOR = new SimpleTier(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, // добывает всё, что может незеритовая
            1800,   // прочность
            8.5F,   // скорость добычи
            3.5F,   // бонус к урону
            12,     // зачаровываемость
            () -> Ingredient.of(Items.IRON_INGOT));

    // Экзокирка: лучше незеритовой
    public static final Tier EXO = new SimpleTier(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
            3200,
            11.0F,
            5.0F,
            22,
            () -> Ingredient.of(Items.DIAMOND));
}
