package com.example.exopickaxes;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(ExoPickaxesMod.MOD_ID)
public class ExoPickaxesMod {
    public static final String MOD_ID = "exopickaxes";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);

    public static final DeferredItem<PickaxeItem> FLUOR_PICKAXE = ITEMS.registerItem(
            "fluor_pickaxe",
            props -> new PickaxeItem(ModTiers.FLUOR,
                    props.attributes(PickaxeItem.createAttributes(ModTiers.FLUOR, 1.0F, -2.8F))),
            new Item.Properties().rarity(Rarity.UNCOMMON));

    public static final DeferredItem<PickaxeItem> EXO_PICKAXE = ITEMS.registerItem(
            "exo_pickaxe",
            props -> new PickaxeItem(ModTiers.EXO,
                    props.attributes(PickaxeItem.createAttributes(ModTiers.EXO, 1.0F, -2.8F))),
            new Item.Properties().rarity(Rarity.RARE).fireResistant());

    public ExoPickaxesMod(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        modEventBus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(FLUOR_PICKAXE);
            event.accept(EXO_PICKAXE);
        }
    }
}
